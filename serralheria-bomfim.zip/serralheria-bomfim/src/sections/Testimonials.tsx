import { Star } from "lucide-react";
import Container from "@/components/ui/Container";
import SectionHeading from "@/components/ui/SectionHeading";
import Reveal from "@/components/ui/Reveal";
import { testimonials } from "@/data/testimonials";

export default function Testimonials() {
  return (
    <section id="depoimentos" aria-labelledby="depoimentos-heading" className="bg-white py-20 sm:py-24">
      <Container>
        <SectionHeading
          eyebrow="Quem já contratou"
          title="O que dizem os clientes"
          description="Avaliações de projetos entregues em Belford Roxo e região."
          id="depoimentos-heading"
        />

        <ul className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((testimonial, index) => (
            <Reveal as="li" key={testimonial.id} delay={index * 80}>
              <figure className="flex h-full flex-col justify-between rounded-lg border border-graphite-200 bg-paper p-6">
                <div>
                  <div className="flex gap-0.5" role="img" aria-label={`Avaliação: ${testimonial.rating} de 5 estrelas`}>
                    {Array.from({ length: 5 }).map((_, starIndex) => (
                      <Star
                        key={starIndex}
                        className={
                          starIndex < testimonial.rating
                            ? "h-4 w-4 fill-brass-500 text-brass-500"
                            : "h-4 w-4 text-graphite-300"
                        }
                        aria-hidden="true"
                      />
                    ))}
                  </div>
                  <blockquote className="mt-4 text-sm leading-relaxed text-graphite-700">
                    “{testimonial.quote}”
                  </blockquote>
                </div>
                <figcaption className="mt-6 border-t border-graphite-200 pt-4">
                  <p className="font-display text-sm uppercase tracking-wide text-graphite-900">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-graphite-500">
                    {testimonial.service} · {testimonial.neighborhood}
                  </p>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </ul>
      </Container>
    </section>
  );
}
